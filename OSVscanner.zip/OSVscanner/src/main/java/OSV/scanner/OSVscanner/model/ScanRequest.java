package OSV.scanner.OSVscanner.model;
import lombok.Data;

@Data
public class ScanRequest {
	private String repoUrl;
}
