package OSV.scanner.OSVscanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsVscannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OsVscannerApplication.class, args);
	}

}
